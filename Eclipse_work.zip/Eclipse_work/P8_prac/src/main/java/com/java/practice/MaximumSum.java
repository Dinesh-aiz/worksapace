package com.java.practice;

public class MaximumSum {
	public int displaymax(int[] array) {
		
		int odd=0,even=0;
		for(int i=0;i<array.length;i++) {
			
			if(array[i]%2==0) {
				even+=array[i];
			}else {
				odd+=array[i];
			}
		}
		if(even<odd) {
			return odd;
		}
		else {
			return even;
		}	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MaximumSum obj = new MaximumSum();
		int[] array= {10,21,31,45,30,40};
		
		System.out.println(obj.displaymax(array));

	}

}
