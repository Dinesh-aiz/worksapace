package com.java.practice;

public class samol23 extends samol22{
	public void Task() {
		
	}
	
	

}
