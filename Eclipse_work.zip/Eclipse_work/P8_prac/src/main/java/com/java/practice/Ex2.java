package com.java.practice;

public class Ex2 {
	public String findstring(String str) {
		
		int count=0;
		String result="";
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i)=='x') {
				count++;
			}else {
			result=result+str.charAt(i);
			}
		}
		for(int i=0;i<count;i++) {
			result+='x';
		}	
		return result;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex2 obj = new Ex2();
		String str = "hxxRDxxXX5x";
		System.out.println(obj.findstring(str));

	}

}
