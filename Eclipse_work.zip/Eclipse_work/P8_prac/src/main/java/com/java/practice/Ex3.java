package com.java.practice;

public class Ex3 {
	
	public int findoddeven(int[] array) {
		
		int odd=0,even=0;
		for(int i=0;i<array.length;i++) {
			if(i%2==0) {
				even+=array[i];
			}
			else {
				odd+=array[i];
			}
		}
		if(even<odd) {
			return odd;
		}
		else {
			return even;
		}
		// TODO Auto-generated method stub

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array= {10,20,30,40,50};
		Ex3 obj = new Ex3();
		System.out.println(obj.findoddeven(array));

	}

}
