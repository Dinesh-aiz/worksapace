package com.java.practice;

public class sample {

	public sample() {
		super();
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) {
		sample s = new sample();
		System.out.println();
		
		String a="Raja";
		String b="Raja";
		String c=new String("Rajan");
		System.out.println(a==c);
		System.out.println(a.compareTo(c));
		System.out.println(c.compareTo(a));//-1
		System.out.println(a.equals(c));//1
	}

}
