package com.java.practice;

public class XXXstring {
	
	public String findx(String a) {
		// TODO Auto-generated method stub
		int count=0;
		String result="";
		//count num of x and not x storing in result
		for(int i=0;i<a.length();i++) {
			if(a.charAt(i)=='x') {
				count++;
				
			}else {
				result=result+a.charAt(i);
			}			
		}
		for(int i=0;i<count;i++) {
			result=result+'x';
		}
		return result;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		XXXstring obj= new XXXstring();
		String a="hxxxXrxex";
		System.out.println(	obj.findx(a));
	
		
		

	}

}
