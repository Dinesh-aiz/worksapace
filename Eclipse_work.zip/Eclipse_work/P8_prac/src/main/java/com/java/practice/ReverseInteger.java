package com.java.practice;

public class ReverseInteger {
	
	static int reverse(int num) {
		
		int rev = 0;
		while(num!=0) {
			rev=rev*10+num % 10;
			num = num/10;
		}
		return rev;
		
	}
	
	public static void main(String []args) 
	{	
		int num= 1234321;
		System.out.println("reversed num: "+reverse(num));
	}

		

}
