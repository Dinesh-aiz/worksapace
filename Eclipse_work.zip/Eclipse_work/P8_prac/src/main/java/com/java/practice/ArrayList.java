package com.java.practice;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;

public class ArrayList {
	
	void display() {
		System.out.println();
	}
	public static void main(String[] args) {
		
		List<Integer> al = new java.util.ArrayList<Integer>();
		al.add(12);
		al.add(6);
		
		List<String> als = new java.util.ArrayList<String>();
		als.add("Dinesh");
		als.add("Raghul");
		
		LinkedList<Integer> ll = new LinkedList<Integer>();
		ll.add(34);
		ll.add(12);
		ll.add(24);
		
		Vector<Integer> ve = new Vector<Integer>();
		ve.add(13);
		ve.add(6);
		ve.add(18);
		
		System.out.println(ve.capacity());
		System.out.println(ve.size());
		
		Stack<String> ss = new Stack<String>();
		ss.add("app");
		ss.add("fall");
		ss.add("das");
		
		for(String list:ss) {
			System.out.println(list);
		}
		
		Collections.sort(ss);
		System.out.println("AFTER SORTING");
		System.out.println(ss);
		
		Integer[] a= {12,13,14,65,3,32};
		Integer[] b= {32,31,24,5,21};
		
		Set<Integer> Hs = new HashSet<Integer>();
		Hs.addAll(Arrays.asList(a));
		
		
 		
		
 	}
	
	

}
