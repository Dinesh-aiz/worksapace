package com.java.practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Employee1 implements Comparable<Employee1> {
	
	int id;
	String name;
	int salary;
	
	Employee1(int id,String name,int salary) {
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	
//	@Override
//	public int compareTo(Employee1 o) {
//		if(salary > o.salary) {
//		return 1;}
//		else if(salary < o.salary) {
//			return -1;
//		}else {
//			return 0;
//		}
//	}
	
	@Override
	public int compareTo(Employee1 t) {
		if(name.charAt(0)>t.name.charAt(0)) {
		return 1;}
		else if(name.charAt(0)<t.name.charAt(0)) {
			return -1;
		}
		else {
			return 0;
		}
	}

public static void main (String []args) {
	
	List<Employee1> obj = new ArrayList<Employee1>();
	obj.add(new Employee1(15, "Santho", 5000));
	obj.add(new Employee1(12, "Happo", 3500));
	obj.add(new Employee1(9, "Dio", 1900));
	obj.add(new Employee1(24, "oreo", 4080));
	
	Collections.sort(obj);
	
	for(Employee1 em:obj) {
		System.out.println(em.id+" "+em.name+" "+em.salary);
	}
}

}
