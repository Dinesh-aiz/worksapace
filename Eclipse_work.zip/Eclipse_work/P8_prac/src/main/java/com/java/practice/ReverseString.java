package com.java.practice;

public class ReverseString {

	public static void main(String[] args) {
		String s = "Dinesh";
		String r = "";
		char ch;
		
		for(int i=0;i<s.length();i++) {
			ch=s.charAt(i);
			r=ch+r;
			
		}
		System.out.println(""+7+2+"");
		System.out.println(r);

	}

}
