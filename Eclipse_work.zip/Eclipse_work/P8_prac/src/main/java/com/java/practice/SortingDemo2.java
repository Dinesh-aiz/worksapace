package com.java.practice;

import java.util.*;


class Employee implements Comparable < Employee >
{
    int empno;
    String ename;
    Employee (int i, String j)
    {
        empno = i;
        ename = j;
    }
    public int compareTo (Employee e1)
    {
        String j1 = this.ename;
        String j2 = e1.ename;
        return j1.compareTo (j2);
    }
    static void display (Vector < Employee > ob)
    {
        for (Employee e1:ob)
        {
            System.out.println (e1.empno + "," + e1.ename);
        }
    }

}

public class SortingDemo2
{
    public static void main (String[]args)
    {
        Vector < Employee > v1 = new Vector < Employee > ();
        v1.add (new Employee (1001, "a"));
        v1.add (new Employee (1004, "d"));
        v1.add (new Employee (1003, "c"));
        v1.add (new Employee (1002, "b"));
        System.out.println ("General format.....");
        Employee.display (v1);
        System.out.println ("After Sorting.....");
        Collections.sort (v1);
        Employee.display (v1);
    }
}