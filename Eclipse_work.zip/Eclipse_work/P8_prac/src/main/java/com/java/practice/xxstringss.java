package com.java.practice;


public class xxstringss {
	
	 public String findingx(String str){
		int count=0;
		String result="";
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i)=='x') {
				count++;
			}
			else {
				result=result+str.charAt(i);
			}
		}for(int i=0;i<count;i++) {
			result=result+'x';
		}
		
		return result;
		 
	 }
	 public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		xxstringss obj = new xxstringss();
		String str= "fexx52XxxXrDx";
		System.out.println(obj.findingx(str));
//		
//		Scanner s = new Scanner(System.in);
//		System.out.println("enter string:");
//		String name = s.nextLine();     
//		Scanner n = new Scanner(System.in);
//		System.out.println("enter num:");
//		int num = n.nextInt();
//
//		System.out.println(name);
//		System.out.println(num+num); 

	}

}
