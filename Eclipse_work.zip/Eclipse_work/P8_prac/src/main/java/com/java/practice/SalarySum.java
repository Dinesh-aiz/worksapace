package com.java.practice;

public class SalarySum {
	
	public int calculate(int salary,int shift) {
		// TODO Auto-generated method stub
		int food=(int) (salary*0.2);
		int travel= (int) (salary *0.3);
		int shiftamt=(int) (salary*0.02)*shift;
		int result=salary+shiftamt-(food+travel);
		return result;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SalarySum obj = new SalarySum();
		int salary=7000;
		int shift=5;
		System.out.println(obj.calculate(salary,shift));

	}

}
