package com.java.practice;

public class MaxSum {
	
	public int findmax(int[] array) {
		
		int even=0,odd=0;
		
		for(int i=0;i<array.length;i++) {			
			if(i%2==0) {
				even+=array[i];
			}else {
				odd+=array[i];
			}
		}
		if(even<odd) {
			return odd;
		}
		else {
			return even;
		}
	}
	public static void main(String[] args) {
		
		MaxSum obj=new MaxSum();
		int[] array= {10,20,30,40,20,50};
		System.out.println(obj.findmax(array));
	}
}
