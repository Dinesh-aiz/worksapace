package com.java.practice;

public class Snippet extends Exception {
	
	 public static void main(String[] args) {
		 
		 try {
			 throw new Snippet();
		 }
		 catch(Snippet e) {
			 System.out.println("Snippet");
		 }
		 
		 finally {
			System.out.println("Hello");
		}
		
		 String s="hello";
		 String st="wall";
		 System.out.println(st.concat(s));
		 System.out.println(s+" "+st);
	}
	
}

