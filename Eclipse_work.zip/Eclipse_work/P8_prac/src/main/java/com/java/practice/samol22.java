package com.java.practice;

public class samol22 {
	public void Task() {
		
}

}
