package com.java.practice;

public class intInput {
	public int inputnum(int input) {
		
		int r=0;
		while(input!=0) {
			int last=input%10;
			r=r*input%10;
			r=input/10;
		}
		return input;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int input=123;
		intInput inp = new intInput();
		System.out.println(inp.inputnum(input));

	}

}
