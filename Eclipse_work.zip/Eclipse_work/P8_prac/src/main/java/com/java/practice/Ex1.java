package com.java.practice;

public class Ex1 {
	
	public int findsums(int salary,int shifts) {
		int food=(int) (salary*0.2);
		int travel = (int) (salary*0.3);
		int shift = (int) (salary*0.02)*shifts;
		int result= salary-(food+travel)+shift;
		
		return result;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex1 obj = new Ex1();
		int salary=7000;
		int shifts=5;
		System.out.print(obj.findsums(salary, shifts));
				
	}

}
