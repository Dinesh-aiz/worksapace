package com.java.practice;

import java.util.ArrayList;
import java.util.Collections;

class Student implements Comparable<Student>{
	int rollno;
	String name;
	int age;

	Student(int r,String n,int a){
		this.age=a;
		this.name=n;
		this.rollno=r;
	}
	@Override
	public int compareTo(Student o) {
		if(age==o.age)
			return 0;
		else if(age>o.age)
			return 1;
		else 
			return -1;
	}
}
public class StudentsComp {

	public static void main(String[] args) {
		
		ArrayList<Student> al = new ArrayList<Student>();
		al.add(new Student(501, "Raghul", 18));
		al.add(new Student(505, "Joseph", 25));
		al.add(new Student(503, "Katho", 20));
		
		Collections.sort(al);
		for(Student sl:al) {
			System.out.println(sl.rollno+" "+sl.name+" "+sl.age);
		}
	}
}

