package com.java.practice;

public class Mapwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
