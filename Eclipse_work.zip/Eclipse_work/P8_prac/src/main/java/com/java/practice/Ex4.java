package com.java.practice;

public class Ex4 {
	
	public int findvalues(int[] array) {
		int odd=0,even=0;
		for(int i=0;i<array.length;i++) {
			
			if(array[i]%2==0) {
				even+=array[i];
			}
			else {
				odd+=array[i];
			}
		}
		
		if(even<odd) {
			return odd;
		}
		else {
			return even;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex4 obj = new Ex4();
		int[] array = {1,2,3,4,5,6,7};
		System.out.println(obj.findvalues(array));

	}

}
