package com.java.practice;


public class Employee2 {
	int a;
	String n;
	
	Employee2(int a,String n) {
		this.a=a;
		this.n=n;
	}
	
	void display() {
		System.out.println("rollno "+a+"name "+n);
	}
	
public static void main (String []args) {
	
	Employee2 emp = new Employee2(101, "DIne");
	Employee2 emp2 = new Employee2(12, "Subras");
	emp.display();
	emp2.display();
}

}
