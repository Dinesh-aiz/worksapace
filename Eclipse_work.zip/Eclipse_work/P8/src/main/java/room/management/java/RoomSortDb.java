package room.management.java;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/RoomSortDb")
public class RoomSortDb extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try {
			Class.forName(getServletContext().getInitParameter("driver"));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}		
		Connection connection = null;
		
		ArrayList<RoomSort> Aobj = new ArrayList<RoomSort>();
		
		HttpSession session = request.getSession();
		String user1 =  (String) session.getAttribute("user1");
		PrintWriter out = response.getWriter();
		LocalDate date = LocalDate.now();
		try {
			connection = DriverManager.getConnection(getServletContext().getInitParameter("url"),getServletContext().getInitParameter("user"),getServletContext().getInitParameter("password"));
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("SELECT * FROM room_management.room_mang");

			out.println(user1+" VANAKAM");
			response.setContentType("text/html");
			out.println("<html>");
			out.println("<body><br><br>");
			out.println("<h1 style='color:green'> Filtered By Amount</h1>");
			out.println("<table border ='1'>");

			out.println("<tr>");
			out.println("<td> ID </td>");
			out.println("<td> DATE </td>");
			out.println("<td> ROOM_No </td>");
			out.println("<td> ROOM_LOCATION </td>");
			out.println("<td> AMOUNT </td>");
			out.println("</tr>");

			while(rs.next()) {
				int id = rs.getInt(5);
				Date date1 = rs.getDate(1);
				int room_no = rs.getInt(2);
				String room_location = rs.getString(3);
				int amount = rs.getInt(4);
				
				Aobj.add(new RoomSort(id,date1,room_no,room_location,amount));
				}
			
			Collections.sort(Aobj);
			for(RoomSort a:Aobj) {
				out.println("<tr>");
				out.println("<td>");
				out.println(a.id);
				out.println("</td>");
				out.println("<td>");
				out.println(a.date);
				out.println("</td>");
				out.println("<td>");
				out.println(a.room_no);
				out.println("</td>");
				out.println("<td>");
				out.println(a.room_location);
				out.println("</td>");
				out.println("<td>");
				out.println(a.amount);
				out.println("</td>");
				out.println("</tr>");
				}
			
			out.println("</table><br>");
			out.println("<form action='RoomManageDb'><input type= 'hidden' name = 'user1' value = '"+user1+"'><button style='background-color:red;color:white'> Return To Booking </button><br>");
			out.println("</body>");
			out.println("</html>");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}}
