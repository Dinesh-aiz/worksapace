package room.management.java;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Authenticator.RequestorType;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RoomDelete")
public class RoomDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Room_model Robj = new Room_model();
		
		Robj.setId(request.getParameter("id"));
		PrintWriter out = response.getWriter();
		
		try {
			Class.forName(getServletContext().getInitParameter("driver"));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
			Connection connection = null;
		
		try {
			connection = DriverManager.getConnection(getServletContext().getInitParameter("url"),getServletContext().getInitParameter("user"),getServletContext().getInitParameter("password"));
			Statement statement = connection.createStatement();
			int rs = statement.executeUpdate("DELETE FROM `room_management`.`room_mang` WHERE (`id` = '"+Robj.getId()+"')");
			if(rs>0) {
			response.sendRedirect("RoomManageDb?removed=SUCCESSFULLY BOOKED");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
