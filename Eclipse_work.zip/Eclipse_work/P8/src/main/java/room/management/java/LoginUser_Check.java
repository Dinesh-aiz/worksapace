package room.management.java;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.ResourceBundle;

public class LoginUser_Check {
	public String check(String name,String pass) throws ClassNotFoundException, SQLException, IOException {
		
		Properties prop = new Properties();
		InputStream is = getClass().getResourceAsStream("sys.properties");
		prop.load(is);
		is.close();
		
		String driver = prop.getProperty("driver");
		String user = prop.getProperty("user");
		String url = prop.getProperty("url");
		//String passw = prop.getProperty("password");
		
		Class.forName(driver);
		
		Connection connection = DriverManager.getConnection(url,user,"root#1412");
		Statement statement = connection.createStatement();
		ResultSet rs = statement.executeQuery("SELECT * FROM room_management.room_user where name_user = '"+name+"' AND password_user ='"+pass+"'");
		
		while(rs.next()) {
			return "Login Successfull";	
		}
		return "INCORRECT CREDENTIALS ENTERED";
	}
}
