package room.management.java;

import java.util.Scanner;

public class factorial {
	
	 static int factorialnum(int num) {
		if(num==0) {
			return 1;
		}
		else {
			return (num*factorialnum(num-1));
		}
	}
	public static void main(String []args) {
		  Scanner s = new Scanner(System.in);
	        int n = s.nextInt(); 
	        int fact=1;
	        
	        fact=factorialnum(n);
	        System.out.println(fact);

	}

}
