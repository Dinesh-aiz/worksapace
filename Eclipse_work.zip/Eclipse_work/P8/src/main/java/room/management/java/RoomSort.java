package room.management.java;

import java.sql.Date;

public class RoomSort implements Comparable<RoomSort>{
	
	int amount;
	Date date;
	int room_no;
	String room_location;
	int id;
	
	RoomSort(int id,Date date,int room_no,String room_location,int amount)
	{
	this.amount=amount;
	this.date=date;
	this.room_no=room_no;
	this.room_location=room_location;
	this.id=id;
	
	}
	@Override
	public int compareTo(RoomSort o) {
		if(amount > o.amount)
		return 1;
		else if(amount<o.amount)
			return -1;
		else
			return 0;
	}
	
	


}
