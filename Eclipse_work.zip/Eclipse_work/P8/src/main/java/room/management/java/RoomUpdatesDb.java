package room.management.java;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/RoomUpdatesDb")
public class RoomUpdatesDb extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Room_model Robj = new Room_model();
		Robj.setDate(request.getParameter("date"));
		Robj.setRoom_no(request.getParameter("room_no"));
		Robj.setRoom_location(request.getParameter("room_location"));
		Robj.setAmount(request.getParameter("amount"));
		Robj.setId(request.getParameter("id"));
		
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		String user1 =  (String) session.getAttribute("user1");
		out.println(user1+" VANAKAM");

		LocalDate today = LocalDate.now();
		
		response.setContentType("text/html");
		out.println("<html>");
		out.println("<body><br><br>");
		out.println("<form action='RoomUpdatesDb' method ='post'>");
		
		out.println("<table border ='1'>");
		out.println("<tr>");
		out.println("<td> DATE </td>");
		out.println("<td> ROOM_No </td>");
		out.println("<td> ROOM_LOCATION </td>");
		out.println("<td> AMOUNT </td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>");
		out.println(Robj.getDate());
		out.println("</td>");
		out.println("<td>");
		out.println(Robj.getRoom_no());
		out.println("</td>");
		out.println("<td>");
		out.println(Robj.getRoom_location());
		out.println("</td>");
		out.println("<td>");
		out.println(Robj.getAmount());
		out.println("</td>");
		out.println("</tr>");
		out.println("</table><br><br>");
		
		
		out.println("Enter Date: <input type='date' min='"+today+"' name='udate' required><br><br>");
		out.println("Enter Available RoomNo: <input type = \"text\" name = \"uroom_no\" required><br><br>");
		out.println("Your ROOM id: <input type = \"text\" name = \"uid\" value = '"+Robj.getId()+"' required readonly=\"readonly\"><br><br>");
		out.println("Enter Room Location: <input type = \"text\" name = \"uroom_location\" required><br><br>");
		out.println("Enter Amount: <input type = \"text\" name = \"uamount\" required><br><br>");
		out.println("<input type = \"SUBMIT\"><br><br>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
		
		String Udate = request.getParameter("udate");
		String Uroom_no = request.getParameter("uroom_no");
		String Uroom_location = request.getParameter("uroom_location");
		String Uamount = request.getParameter("uamount");
		String Uid = request.getParameter("uid");
		
		try {
			Class.forName(getServletContext().getInitParameter("driver"));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection connection = null;
		
		try {
			connection = DriverManager.getConnection(getServletContext().getInitParameter("url"),getServletContext().getInitParameter("user"),getServletContext().getInitParameter("password"));
			Statement statement = connection.createStatement();
			if(Robj.getDate()!=""&&Robj.getRoom_no()!=""&&Robj.getRoom_location()!=""&&Robj.getAmount()!="") {
			int sup = statement.executeUpdate("UPDATE room_management.room_mang SET Date='"+Udate+"', Room_no='"+Uroom_no+"', Room_Location='"+Uroom_location+"', Amount='"+Uamount+"' WHERE (id='"+Uid+"')");
			System.out.println(sup);
			if(sup>0) {
			response.sendRedirect("RoomManageDb?updated=UPDATION SUCCESS");
			}

			}else {
				out.println("ENTER COMPLETE DETAILS");
			}
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
	}

}
