package room.management.java;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/UserLoginDb")
public class UserLoginDb extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		
		User_Model mobj = new User_Model();

		mobj.setName(request.getParameter("name"));
		mobj.setPass(request.getParameter("pass"));
		String Result = null;
		PrintWriter out = response.getWriter();
		
		LoginUser_Check obj = new LoginUser_Check();
		

		if(mobj.getName()!=""&&mobj.getPass()!="") {
			try {
				Result = obj.check(mobj.getName(), mobj.getPass());
				out.print(Result);
				if(Result.equals("Login Successfull")) {
					session.setAttribute("user1", mobj.getName());
					RequestDispatcher rd = request.getRequestDispatcher("RoomManageDb");
					rd.forward(request, response);
				}
				else {
					request.setAttribute("user3", "INCORRECT CREDENTIALS");
					RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
					rd.forward(request, response);
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}	
}
