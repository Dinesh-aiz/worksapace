package room.management.java;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.jni.Local;

@WebServlet("/RoomInsertDb")
public class RoomInsertDb extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Room_model Robj = new Room_model();
		Robj.setDate(request.getParameter("date"));
		Robj.setRoom_no(request.getParameter("room_no"));
		Robj.setRoom_location(request.getParameter("room_location"));
		Robj.setAmount(request.getParameter("amount"));
		
		HttpSession session = request.getSession();
		String user1 =  (String) session.getAttribute("user1");
		PrintWriter out = response.getWriter();
		out.println(user1+" VANAKAM");
		LocalDate today = LocalDate.now();
		
		response.setContentType("text/html");
		
		out.println("<html>");
		out.println("<body><br><br>");
	
		out.println("<form action='RoomInsertDb' method ='post'>");
		out.println("Enter Date: <input type='date' min='"+today+"' name='date'><br><br>");
		out.println("Enter Available RoomNo: <input type = \"text\" name = \"room_no\"><br><br>");
		out.println("Enter Room Location: <input type = \"text\" name = \"room_location\"><br><br>");
		out.println("Enter Amount: <input type = \"text\" name = \"amount\"><br><br>");
		out.println("<button type ='submit' style='background-color:red;color:white'>SUBMIT</button>");
		out.println("</form>");	
		out.println("</body>");
		out.println("</html>");
	
		try {
			Class.forName(getServletContext().getInitParameter("driver"));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection connection = null;
		
		try {
			connection = DriverManager.getConnection(getServletContext().getInitParameter("url"),getServletContext().getInitParameter("user"),getServletContext().getInitParameter("password"));
			Statement statement = connection.createStatement();
			if(Robj.getDate()!=""&&Robj.getRoom_no()!=""&&Robj.getRoom_location()!=""&&Robj.getAmount()!="") {
			int rs = statement.executeUpdate("INSERT INTO `room_management`.`room_mang` (`Date`, `Room_no`, `Room_Location`, `Amount`) VALUES ('"+Robj.getDate()+"', '"+Robj.getRoom_no()+"', '"+Robj.getRoom_location()+"', '"+Robj.getAmount()+"')");
			System.out.println(rs);
			
			response.sendRedirect("RoomManageDb?inserted=ROOMS ADDED");
			}else {
				out.println("ENTER COMPLETE DETAILS");
			}
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
