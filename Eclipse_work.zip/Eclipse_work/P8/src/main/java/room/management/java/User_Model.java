package room.management.java;

public class User_Model {
	
	private String name;
	private String pass;
	private String Reg_name;
	private String Reg_pass;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getReg_name() {
		return Reg_name;
	}
	public void setReg_name(String reg_name) {
		Reg_name = reg_name;
	}
	public String getReg_pass() {
		return Reg_pass;
	}
	public void setReg_pass(String reg_pass) {
		Reg_pass = reg_pass;
	}

}
