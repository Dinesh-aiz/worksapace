package room.management.java;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UserRegisterDb")
public class UserRegisterDb extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		User_Model Mobj = new User_Model();

		Mobj.setReg_name(request.getParameter("Username"));
		Mobj.setReg_pass(request.getParameter("Userpassword"));
		
		PrintWriter out = response.getWriter();
		try {
			Class.forName(getServletContext().getInitParameter("driver"));
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
		
		RegisterUser_Check obj = new RegisterUser_Check();
		Connection connection = null;

		try {
			connection = DriverManager.getConnection(getServletContext().getInitParameter("url"),getServletContext().getInitParameter("user"),getServletContext().getInitParameter("password"));
			Statement statement = connection.createStatement();
			if(Mobj.getReg_name()!=""&&Mobj.getReg_pass()!="") {
				if(obj.check1(Mobj.getReg_name())==false) {
					int result = statement.executeUpdate("INSERT INTO `room_management`.`room_user` (`name_user`, `password_user`) VALUES ('"+Mobj.getReg_name()+"','"+Mobj.getReg_pass()+"')");

					if(result>0) {
						request.setAttribute("UserReg", "Successfully Registered");
						RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
						rd.forward(request, response);
					}
				}else{
					try {
						throw new UserException("TERRIBLE");

					} catch (Exception e) {
						String mssg = e.getMessage();

						request.setAttribute("UserReg", mssg);
						RequestDispatcher rd = request.getRequestDispatcher("/Register.jsp");
						rd.forward(request, response);				
					}	
				}
			}else {
				out.println("Invalid Registration");
			}
		}
		catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println(connection);
	}
}

