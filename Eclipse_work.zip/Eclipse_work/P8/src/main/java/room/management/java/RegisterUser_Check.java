package room.management.java;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RegisterUser_Check {

	public boolean check1(String Username) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/room_management","root","root#1412");
		Statement statement = connection.createStatement();
		ResultSet rs = statement.executeQuery("SELECT * FROM room_management.room_user where name_user = '"+Username+"'");
		
		while(rs.next()) {
			return true;		
			}
		return false;
	}

}
