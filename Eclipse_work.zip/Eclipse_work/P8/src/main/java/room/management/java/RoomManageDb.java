package room.management.java;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/RoomManageDb")
public class RoomManageDb extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String user1 = (String) session.getAttribute("user1");

		PrintWriter out = response.getWriter();
		
		try {
			Class.forName(getServletContext().getInitParameter("driver"));
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection connection = null;

		try {
			connection = DriverManager.getConnection(getServletContext().getInitParameter("url"),getServletContext().getInitParameter("user"),getServletContext().getInitParameter("password"));
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("SELECT * FROM room_mang");
			out.println(user1+" VANAKAM");
			response.setContentType("text/html");

			//out.println("Date: "+rs.getDate(1)+" Room_no: "+rs.getInt(2)+" Room_Location: "+rs.getString(3)+" Amount: "+rs.getInt(4));

			out.println("<html>");
			out.println("<body><br><br>");
			out.println("<table border ='1'>");

			out.println("<tr>");
			out.println("<td> ID </td>");
			out.println("<td> DATE </td>");
			out.println("<td> ROOM_No </td>");
			out.println("<td> ROOM_LOCATION </td>");
			out.println("<td> AMOUNT </td>");
			out.println("<td> ACTION </td>");
			out.println("<td> UPDATE </td>");
			out.println("</tr>");

			while(rs.next()) {
				out.println("<tr>");
				out.println("<td>");
				out.println(rs.getInt(5));
				out.println("</td>");
				out.println("<td>");
				out.println(rs.getDate(1));
				out.println("</td>");
				out.println("<td>");
				out.println(rs.getInt(2));
				out.println("</td>");
				out.println("<td>");
				out.println(rs.getString(3));
				out.println("</td>");
				out.println("<td>");
				out.println(rs.getInt(4));
				out.println("</td>");
				
				out.println("<td>");	
				out.println("<form action='RoomDelete' method ='post'>");
				out.println("<input type ='hidden' name = 'id' value ='"+rs.getInt(5)+"'>");
				out.println("<button type ='submit' style='background-color:red;color:white'>Book</button>");
				out.println("</form>");				
				out.println("</td>");

				out.println("<td>");
				out.println("<form action='RoomUpdatesDb' method ='post'>");
				out.println("<input type ='hidden' name = 'id' value ='"+rs.getInt(5)+"'>");
				out.println("<input type ='hidden' name = 'date' value ='"+rs.getDate(1)+"'>");
				out.println("<input type ='hidden' name = 'room_no' value ='"+rs.getInt(2)+"'>");
				out.println("<input type ='hidden' name = 'room_location' value ='"+rs.getString(3)+"'>");
				out.println("<input type ='hidden' name = 'amount' value ='"+rs.getInt(4)+"'>");
				out.println("<input type ='submit' value='EDIT'>");
				out.println("</form>");
				out.println("</td>");
				
				out.println("</tr>");
			}
			out.println("</table><br>");
			
			String um =(String) request.getParameter("updated");
			if(um!=null){
				out.println("<h1>"+um+"</h1><br>");
			}
			String rm =(String) request.getParameter("removed");
			if(rm!=null){
				out.println("<h1>"+rm+"</h1><br>");
			}
			String im =(String) request.getParameter("inserted");
			if(im!=null){
				out.println("<h1>"+im+"</h1><br>");
			}
			
			out.println("<td>");
			out.println("<form action='RoomInsertDb' method = 'post'><input type= 'hidden' name = 'user1' value= '"+user1+"'><button> ADD ROOMS </button></form><br>");
			out.println("<a href ='login.jsp'><button>LOGOUT</button></a><br><br>");
			out.println("<form action='RoomSortDb' method='post'><input type= 'hidden' name = 'user1' value = '"+user1+"'><button> FILTER </button><br>");
			out.println("<input type ='hidden' name = 'id' value ='"+rs.getInt(5)+"'>");
			out.println("<input type ='hidden' name = 'date' value ='"+rs.getDate(1)+"'>");
			out.println("<input type ='hidden' name = 'room_no' value ='"+rs.getInt(2)+"'>");
			out.println("<input type ='hidden' name = 'room_location' value ='"+rs.getString(3)+"'>");
			out.println("<input type ='hidden' name = 'amount' value ='"+rs.getInt(4)+"'>");
			out.println("</form>");
			out.println("</td>");
			
			out.println("</	body>");
			out.println("</html>");	
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(connection);

	}


}
