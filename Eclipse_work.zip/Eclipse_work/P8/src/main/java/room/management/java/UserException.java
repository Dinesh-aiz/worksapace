package room.management.java;

public class UserException extends Exception {
	
	public UserException(String msg){
		super(msg);
	
	}

}
